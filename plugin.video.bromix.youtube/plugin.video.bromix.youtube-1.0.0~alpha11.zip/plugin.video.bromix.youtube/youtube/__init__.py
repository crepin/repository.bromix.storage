"""
Version 1.0.0
- initial version
"""

from youtube import YouTubeClient