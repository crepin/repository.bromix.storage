"""
Version 1.0.0
- initial version
"""

from youtube import YouTubeClient

def getVideoInformations(video_id):
    return {}