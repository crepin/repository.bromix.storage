from resources.lib import kodimon
from resources.lib import nine_gag

__provider__ = nine_gag.Provider()
kodimon.run(__provider__)