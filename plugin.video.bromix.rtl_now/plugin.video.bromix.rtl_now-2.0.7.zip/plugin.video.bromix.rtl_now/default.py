from resources.lib.kodion import runner
from resources.lib import rtlinteractive

__provider__ = rtlinteractive.Provider()
runner.run(__provider__)