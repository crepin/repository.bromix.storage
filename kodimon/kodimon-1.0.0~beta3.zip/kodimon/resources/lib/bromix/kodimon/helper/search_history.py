import urllib


class SearchHistory(object):
    def __init__(self, plugin):
        self._plugin = plugin
        self._settings = plugin.get_settings()
        
        search_history_string = self._settings.get_string('bromix.kodimon.search.history', '')
        if search_history_string=='':
            self._items = []
        else:
            self._items = search_history_string.split('|')
            
            for i in range(len(self._items)):
                entry = self._items[i]
                if len(entry)>0:
                    entry = urllib.unquote(entry)
                    self._items[i] = entry
                    pass
                pass
            pass
        
        self._size = self._settings.get_int('bromix.kodimon.search.history.size', 10)
        pass
    
    def is_empty(self):
        return len(self._items)==0
    
    def _create_string(self):
        _copy = []
        for item in self._items:
            _copy.append(urllib.quote(item))
            pass
        return '|'.join(_copy)
    
    def get_items(self):
        return self._items
    
    def clear(self):
        self._items = []
        self._store()
    
    def remove(self, search):
        if search in self._items:
            index = self._items.index(search)
            del self._items[index]
            self._store()
            pass
        pass
    
    def update(self, search):
        self.remove(search)
        
        _items = [search]
        _items.extend(self._items)
        
        cut_off = len(_items)-self._size
        del _items[len(_items)-cut_off:]
        self._items = _items
        self._store()
        pass
    
    def _store(self):
        self._settings.set_string('bromix.kodimon.search.history', self._create_string())