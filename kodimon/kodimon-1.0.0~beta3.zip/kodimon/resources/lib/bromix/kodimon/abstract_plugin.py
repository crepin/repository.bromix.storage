import urllib
import os


class AbstractPlugin(object):
    def __init__(self, plugin_name=None, plugin_id=None):
        """

        :param plugin_name:
        :param plugin_id:
        """
        object.__init__(self)
        
        self._plugin_name = plugin_name
        self._plugin_id = plugin_id
        pass

    def create_url(self, path='', params={}):
        url = None
        if path is not None and len(path) > 0:
            url = "%s://%s/%s/" % ('plugin', self._plugin_id, path.strip('/'))
        else:
            url = "%s://%s/" % ('plugin', self._plugin_id)
    
        if params is not None and len(params) > 0:
            url = url + '?' + urllib.urlencode(params)
            pass
        
        return url
    
    def create_url_from_item(self, base_item):
        return self.create_url(base_item.get_path(), base_item.get_params())

    def get_data_path(self):
        raise NotImplementedError()

    def get_native_path(self):
        raise NotImplementedError()
    
    def get_fanart(self):
        return os.path.join(self.get_native_path(), 'fanart.jpg')
    
    def create_resource_path(self, relative_path):
        path_comps = relative_path.split('/')
        path = os.path.join(self.get_native_path(), 'resources', *path_comps)
        return path
    
    def get_path(self):
        raise NotImplementedError()
    
    def get_params(self):
        raise NotImplementedError()
    
    def get_name(self):
        return self._plugin_name
    
    def get_id(self):
        return self._plugin_id
    
    def get_handle(self):
        raise NotImplementedError()
    
    def get_settings(self):
        raise NotImplementedError()
    
    def localize(self, text_id, default_text=None):
        raise NotImplementedError()
    
    def localize_by_mapping(self, text_id, mapping, default_text=None):
        map_id = mapping.get(text_id, None)
        if map_id!=None:
            text = self.localize(map_id, default_text)
            if text!=map_id:
                return text
            pass
        
        if default_text!=None:
            return default_text
        
        return text_id
    
    def set_content_type(self, content_type):
        raise NotImplementedError()
    
    def add_sort_method(self, sort_method):
        raise NotImplementedError()