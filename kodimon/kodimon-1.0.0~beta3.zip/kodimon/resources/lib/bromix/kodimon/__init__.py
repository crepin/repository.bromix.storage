"""
Import switch for the real deal or for the mock for some testing.
"""
from abstract_api import *
try:
    from impl.xbmc.xbmc_api import *
    from impl.xbmc.xbmc_plugin import XbmcPlugin as Plugin    
except ImportError:
    from impl.mock.mock_api import *
    from impl.mock.mock_plugin import MockPlugin as Plugin
    pass

class KodimonException(Exception):
    pass