#import pydevd
#pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)

from resources.lib.bromix import kodimon
__plugin__ = kodimon.Plugin()

from resources.lib.bromix import prosiebensat1
__provider__ = prosiebensat1.Provider(__plugin__)
kodimon.run(__provider__)