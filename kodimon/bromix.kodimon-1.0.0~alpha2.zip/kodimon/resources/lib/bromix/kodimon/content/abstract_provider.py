import re
import urllib

class AbstractProvider(object):
    INTERNAL_SEARCH_PATH = 'bromix.kodimon.search'
    REFRESH_CONTAINER_ON_SEARCH = True
    
    INTERNAL_FAVS_PATH = 'bromix.kodimon.favs'
    
    def __init__(self, plugin):
        self._refresh_container_on_search = True
        
        self._plugin = plugin
        self._path_mapping = {}
        self._localization_mapping = {'search.new': None,
                                      'search.new.title': None
                                      }
        
        """
        Test each method of this class for the appended attribute '_re_match' by the
        decorator (RegisterPath).
        The '_re_match' attributes describes the path which must match for the decorated method.
        """
        
        for method_name in dir(self):
            method = getattr(self, method_name)
            if hasattr(method, '_re_path'):
                self.register_path(method._re_path, method_name)
                pass
            pass
        pass
    
    def register_default_search(self, localization_mapping={}):
        self._localization_mapping.update(localization_mapping)
        self.register_path('^/'+self.INTERNAL_SEARCH_PATH+'/((.*)/)?$', 'internal_search')
        pass
    
    def register_default_favs_support(self, localization_mapping={}):
        self._localization_mapping.update(localization_mapping)
        self.register_path('^/'+self.INTERNAL_FAVS_PATH+'/(add|remove|list)/?$', 'internal_favs')
        pass
    
    def get_plugin(self):
        return self._plugin
    
    def localize(self, text_id, default_text=None):
        return self._plugin.localize(text_id, default_text)
    
    def localize_by_mapping(self, text_id):
        return self._plugin.localize_by_mapping(text_id, self._localization_mapping)
    
    def register_path(self, re_path, method_name):
        self._path_mapping[re_path]=method_name
    
    def sort_items_by_name(self, content_items=[], reverse=False):
        def _sort(item):
            return item.get_name().upper()
        
        return sorted(content_items, key=_sort, reverse=reverse)
    
    def sort_video_items_by_info_label(self, content_items=[], info_label='aired', reverse=False):
        def _sort(item):            
            _info_labels = item.create_info_label()
            return _info_labels.get(info_label, '')
        
        return sorted(content_items, key=_sort, reverse=reverse)
    
    def navigate(self, path, params={}):
        for key in self._path_mapping:
            re_match = re.search(key, path)
            if re_match!=None:
                method_name = self._path_mapping.get(key, '')
                method = getattr(self, method_name)
                if method!=None:
                    return method(path, params, re_match)
                pass
            pass
        
        from ...kodimon import KodimonException
        raise KodimonException("Mapping for path '%s' not found" % (path))
    
    def on_search(self, search_text, path, params, re_match):
        raise NotImplementedError()
    
    def internal_favs(self, path, params, re_match):
        from ..helper import FavsManager
        favs_manager = FavsManager(self._plugin)

        command = re_match.group(1)
        if command == 'add':
            fav_item = FavsManager.create_directory_item_from_params(params)
            favs_manager.add_fav(fav_item)
            pass
        elif command == 'remove':
            fav_item = FavsManager.create_directory_item_from_params(params)
            favs_manager.remove_fav(fav_item)
            from ...kodimon import refresh_container
            refresh_container()
            pass
        elif command == 'list':
            from ..helper import contextmenu
            directory_items = self.sort_items_by_name(favs_manager.get_favs())

            """
            update the context menu
            """
            for directory_item in directory_items:
                context_menu = []
                remove_item = contextmenu.create_default_remove_from_favs(self._plugin,
                                                                          self.localize_by_mapping('favs.remove'),
                                                                          directory_item)
                context_menu.append(remove_item)
                directory_item.set_context_menu(context_menu)
                pass

            return directory_items
        else:
            # do something
            pass
        pass

    def internal_search(self, path, params, re_match):
        from ...kodimon import refresh_container, create_content_path
        from ...kodimon.helper import SearchHistory
        search_history = SearchHistory(self.get_plugin())
        search_text = re_match.group(2)
        if search_text is not None and search_text != '':
            search_text = urllib.unquote(search_text)
            search_history.update(search_text)
            if self.REFRESH_CONTAINER_ON_SEARCH:
                refresh_container()
                pass
            return self.on_search(search_text, path, params, re_match)
        
        if search_history.is_empty() or params.get('command', '') == 'new':
            from ...kodimon import input
            result, text = input.on_keyboard_input(self.localize_by_mapping('search.new.title'))
            if result:
                search_history.update(text)
                if self.REFRESH_CONTAINER_ON_SEARCH:
                    refresh_container()
                    pass
                return self.on_search(text, path, params, re_match)
            pass
        elif params.get('command', '')=='remove':
            search_history.remove(params.get('name', ''))
            refresh_container()
            pass
        else:
            result = []
            
            from . import DirectoryItem
            
            """
            Provide a "New Search..." command.
            """
            directory_item = DirectoryItem(name='[B]'+self.localize_by_mapping('search.new')+'[/B]',
                                           path=create_content_path(self.INTERNAL_SEARCH_PATH),
                                           params={'command': 'new'},
                                           image_url=self.get_plugin().create_resource_path('media/search.png'))
            
            directory_item.set_fanart(self.get_plugin().get_fanart())
            result.append(directory_item)
            
            """
            Add each item from the search history. 
            """
            for item in search_history.get_items():
                directory_item = DirectoryItem(name=item,
                                              path=create_content_path([self.INTERNAL_SEARCH_PATH, item]),
                                              params={'page': 1},
                                              image_url=self.get_plugin().create_resource_path('media/search.png')
                                              )
                directory_item.set_fanart(self.get_plugin().get_fanart())
                
                
                from ..helper import contextmenu
                context_menu = []
                context_menu.append(contextmenu.create_run_plugin(self._plugin,
                                                                  self.localize_by_mapping('search.context.remove'),
                                                                  path=self.INTERNAL_SEARCH_PATH,
                                                                  params={'command': 'remove',
                                                                          'name': item}))
                directory_item.set_context_menu(context_menu)
                result.append(directory_item)
                pass
            
            return result
        
        return False
    
    pass