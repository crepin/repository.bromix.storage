import unittest

import urlparse
import json

from resources.lib.bromix import kodimon
from resources.lib.bromix.kodimon.helper import contextmenu
from resources.lib.bromix.kodimon.content import DirectoryItem

class TestContextMenu(unittest.TestCase):
    def setUp(self):
        self._plugin = kodimon.Plugin('PluginName', 'PluginId')
        pass
    
    def test_create_default_add_to_favs(self):
        item = DirectoryItem(name='adada',
                             path='/pro7/library/277/',
                             params={'param1': 'value1',
                                     'param2': 'value2'},
                             image_url='image url')
        item.set_fanart('fanart url')
        
        context_item = contextmenu.create_default_add_to_favs(self._plugin,
                                                          'Add me to favs',
                                                          item
                                                          )
        
        url_components = urlparse.urlparse(context_item[1])
        path = url_components[2]
        query = url_components[4]
        fav_params = dict(urlparse.parse_qsl(query))
        params = json.loads(fav_params.get('params', '').replace("'", "\""))
        pass
    
    def test_run_plugin(self):
        item = contextmenu.create_run_plugin(self._plugin,
                                           'Do stuff',
                                           path=kodimon.create_content_path('search'),
                                           params={'name': 'Galileo'}
                                           )
        self.assertEqual('Do stuff', item[0])
        self.assertEqual('RunPlugin(plugin://PluginId/search/?name=Galileo)', item[1])
        pass

if __name__ == "__main__":
    unittest.main()
    pass