from distutils.extension import read_setup_file

__author__ = 'bromix'


import json
import shelve
import os
import hashlib

from ..content import DirectoryItem

class FavsManager(object):
    def __init__(self, plugin):
        self._plugin = plugin

        self._favs_dir = os.path.join(self._plugin.get_data_path(), u'bromix', u'kodimon', u'favs')
        pass

    @staticmethod
    def _create_id_from_item(base_item):
        m = hashlib.md5()
        m.update(base_item.get_name().encode('UTF-8'))
        m.update(base_item.get_path())
        for key in base_item.get_params():
            m.update(key)
            m.update(base_item.get_params().get(key, None))
            pass
        return m.hexdigest().encode('UTF-8')

    def _open_fav_file(self):
        if not os.path.exists(self._favs_dir):
            os.makedirs(self._favs_dir)
            pass

        favs_file = os.path.join(self._favs_dir, 'data')
        return shelve.open(favs_file)

    def add_fav(self, base_item):
        fav_id = self._create_id_from_item(base_item)

        fav_file = self._open_fav_file()
        fav_file[fav_id] = base_item
        fav_file.close()
        pass

    def clear(self):
        fav_file = self._open_fav_file()
        fav_file.clear()
        fav_file.close()
        pass

    def get_favs(self):
        result = []

        fav_file = self._open_fav_file()
        for key in fav_file.keys():
            directory_item = fav_file[key]
            result.append(directory_item)
            pass

        return result

    def remove_fav(self, base_item):
        fav_id = self._create_id_from_item(base_item)
        fav_file = self._open_fav_file()
        if fav_file.has_key(fav_id):
            del fav_file[fav_id]
            pass
        fav_file.close()
        pass

    @staticmethod
    def create_directory_item_from_params(params):
        new_item = DirectoryItem(name='dummy', path='dummy')

        new_item._path = params.get('path', None)
        new_item._name = params.get('name', '').decode('utf-8')
        new_item._image_url = params.get('thumb', u'')
        new_item._fanart = params.get('fanart', None)
        new_item._params = json.loads(params.get('params', '').replace("'", "\""))

        return new_item
    pass