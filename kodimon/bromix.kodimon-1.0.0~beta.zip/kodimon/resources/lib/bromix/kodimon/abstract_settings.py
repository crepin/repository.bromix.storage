class AbstractSettings(object):
    def __init__(self, *args, **kwargs):
        object.__init__(self, *args, **kwargs)
        pass
    
    def get_string(self, setting_id, default_value=None):
        raise NotImplementedError()
    
    def set_string(self, setting_id, value):
        raise NotImplementedError()
    
    def get_int(self, setting_id, default_value):
        value = self.get_string(setting_id)
        if value==None or value=='':
            return default_value
         
        try:
            return int(value)
        except:
            # dp nothing
            pass
        
        return default_value
    
    def set_int(self, setting_id, value):
        self.set_string(setting_id, str(value))
        pass
    
    def set_bool(self, setting_id, value):
        if value==True:
            self.set_string(setting_id, 'true')
        else:
            self.set_string(setting_id, 'false')
            
    def get_bool(self, setting_id, default_value):
        value = self.get_string(setting_id)
        if value==None or value=='':
            return default_value
        
        if value!='false' and value!='true':
            return default_value
         
        return value=='true'
    
    pass