class BaseItem(object):
    def __init__(self, name, path, params={}, image_url=u''):
        self._name = name
        self._path = path
        self._url = None
        self._params = params
        self._fanart = None
        self._context_menu = None
        
        self.set_image_url(image_url)
        pass

    def get_name(self):
        return self._name
    
    def get_path(self):
        return self._path
    
    def set_url(self, url):
        self._url = url
        pass
    
    def get_url(self):
        return self._url
    
    def get_params(self):
        return self._params
    
    def set_image_url(self, image_url):
        if image_url is not None:
            self._image_url = image_url
        else:
            self._image_url = u''
        pass
    
    def get_image_url(self):
        return self._image_url
    
    def set_fanart(self, fanart):
        if fanart is not None and len(fanart) == 0:
            self._fanart = fanart
        else:
            self._fanart = fanart
        pass
    
    def get_fanart(self):
        return self._fanart
    
    def set_context_menu(self, context_menu):
        if len(context_menu)==0:
            self._context_menu = None
        else:
            self._context_menu = context_menu
        pass
    
    def get_context_menu(self):
        return self._context_menu
    
    pass