import unittest

from resources.lib.bromix.kodimon.content import BaseItem

class TestBaseItem(unittest.TestCase):
    def setUp(self):
        pass
        
    def test_get_name(self):
        item = BaseItem(name="Playlists",
                        path="/playlists/"
                        )
        
        self.assertEqual("Playlists", item.get_name())
        pass
    
    def test_get_path(self):
        item = BaseItem(name="Playlists",
                        path="/playlists/"
                        )
        
        self.assertEqual("/playlists/", item.get_path())
        pass
    
    def test_get_params(self):
        item = BaseItem(name="Playlists",
                        path="/playlists/",
                        params={'id': '123456', 'id2': 'abcdef'}
                        )
        
        self.assertEqual(item.get_params().get('id', ''), '123456')
        self.assertEqual(item.get_params().get('id2', ''), 'abcdef')
        pass
    
    def test_set_image_url(self):
        item = BaseItem(name="Playlists",
                        path="/playlists/",
                        params={'id': '123456', 'id2': 'abcdef'},
                        image_url=None
                        )
        
        self.assertEqual(item.get_image_url(), u'')
        
        item.set_image_url('stuff')
        self.assertEqual(item.get_image_url(), 'stuff')
        
        item.set_image_url(None)
        self.assertEqual(item.get_image_url(), '')
        pass
    
    def test_get_image_url(self):
        item = BaseItem(name="Playlists",
                        path="/playlists/",
                        params={'id': '123456', 'id2': 'abcdef'},
                        image_url='some_url'
                        )
        
        self.assertEqual(item.get_image_url(), 'some_url')
        pass
    
    def test_get_fanart(self):
        item = BaseItem(name="Playlists",
                        path="/playlists/"
                        )
        item.set_fanart('some_fanart')
        
        self.assertEqual(item.get_fanart(), 'some_fanart')
        pass

if __name__ == "__main__":
    unittest.main()
    pass