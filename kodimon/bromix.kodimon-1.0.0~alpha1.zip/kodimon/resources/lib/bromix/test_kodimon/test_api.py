import unittest

from resources.lib.bromix import kodimon

class TestApi(unittest.TestCase):
    def setUp(self):
        pass
    
    def test_log(self):
        kodimon.log("Hello")
        pass
    
    def test_create_content_path(self):
        path = kodimon.create_content_path(['search/', '/new', 'entry'])
        self.assertEqual('/search/new/entry/', path)
        
        path = kodimon.create_content_path(['search/ups', '/new', 'entry'])
        self.assertEqual('/search/ups/new/entry/', path)
        
        path = kodimon.create_content_path('search//new/entry////')
        self.assertEqual('/search/new/entry/', path)
        pass

if __name__ == "__main__":
    unittest.main()
    pass