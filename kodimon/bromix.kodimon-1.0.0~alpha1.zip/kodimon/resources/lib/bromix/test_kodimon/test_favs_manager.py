from resources.lib.bromix.kodimon.impl.mock.mock_api import refresh_container

__author__ = 'bromix'

import unittest
import urlparse
import re

from resources.lib.bromix import kodimon
from resources.lib.bromix.kodimon.content import DirectoryItem
from resources.lib.bromix.kodimon.helper import FavsManager, contextmenu


class TestFavsManager(unittest.TestCase):
    def setUp(self):
        self._plugin = kodimon.Plugin()
        pass

    def test_fav_item(self):
        item = DirectoryItem(name='adada',
                             path='/pro7/library/277/',
                             params={'param1': 'value1',
                                     'param2': 'value2'},
                             image_url='image url')
        item.set_fanart('fanart url')

        context_item = contextmenu.create_default_add_to_favs(self._plugin,
                                                              'Add me to favs',
                                                              item)
        params = {}
        re_match = re.match("RunPlugin\((.*)\)", context_item[1])
        if re_match is not None:
            url_components = urlparse.urlparse(re_match.group(1))
            path = url_components[2]
            query = url_components[4]
            params = dict(urlparse.parse_qsl(query))
            pass

        fav_item = FavsManager.create_directory_item_from_params(params)

        self.assertEqual(fav_item.get_name(), 'adada')
        self.assertEqual(fav_item.get_path(), '/pro7/library/277/')
        self.assertEqual(fav_item.get_image_url(), 'image url')
        self.assertEqual(fav_item.get_fanart(), 'fanart url')
        self.assertEqual(fav_item.get_params().get('param1', None), 'value1')
        self.assertEqual(fav_item.get_params().get('param2', None), 'value2')
        pass

    def test_add_fav(self):
        item = DirectoryItem(name='adada',
                             path='/pro7/library/277/',
                             params={'param1': 'value1',
                                     'param2': 'value2'},
                             image_url='image url')
        item.set_fanart('fanart url')

        favs_manager = FavsManager(self._plugin)
        favs_manager.clear_favs()
        favs_manager.add_fav(item)

        favs = favs_manager.get_favs()
        self.assertEqual(1, len(favs))

        favs_manager.add_fav(item)

        favs = favs_manager.get_favs()
        self.assertEqual(1, len(favs))
        pass

    def test_remove_fav(self):
        item = DirectoryItem(name='adada',
                             path='/pro7/library/277/',
                             params={'param1': 'value1',
                                     'param2': 'value2'},
                             image_url='image url')
        item.set_fanart('fanart url')

        favs_manager = FavsManager(self._plugin)
        favs_manager.clear_favs()
        favs_manager.add_fav(item)

        favs = favs_manager.get_favs()
        self.assertEqual(1, len(favs))

        favs_manager.remove_fav(item)

        favs = favs_manager.get_favs()
        self.assertEqual(0, len(favs))
        pass
    pass