__author__ = 'bromix'


import json
import os
import hashlib

from ..content import DirectoryItem

class FavsManager(object):
    def __init__(self, plugin):
        self._plugin = plugin

        self._favs_file = os.path.join(self._plugin.get_data_path(), 'bromix.kodimon.favs.json')
        self._favs = {}
        pass

    def _load_favs(self):
        self._favs = {}
        if self._favs_file is not None and os.path.exists(self._favs_file):
            try:
                file = open(self._favs_file, 'r')
                self._favs = json.loads(file.read(), encoding='utf-8')
            except:
                #do nothing
                pass

        pass

    def _store_favs(self):
        if self._favs_file is not None:
            with open(self._favs_file, 'w') as outfile:
                json.dump(self._favs, outfile, sort_keys = True, indent = 4, encoding='utf-8')
                pass
            pass
        pass

    def _create_id_from_item(self, base_item):
        m = hashlib.md5()
        m.update(base_item.get_name())
        m.update(base_item.get_path())
        for key in base_item.get_params():
            m.update(key)
            m.update(base_item.get_params().get(key, None))
            pass
        return m.hexdigest()

    def add_fav(self, base_item):
        self._load_favs()

        fav_item_data = {'path': base_item.get_path(),
                         'name': base_item.get_name(),
                         'thumb': base_item.get_image_url(),
                         'params': base_item.get_params()}
        if base_item.get_fanart() is not None:
            fav_item_data['fanart']=base_item.get_fanart()

        fav_id = self._create_id_from_item(base_item)
        self._favs[fav_id] = fav_item_data
        self._store_favs()
        pass

    def clear_favs(self):
        self._favs = {}
        self._store_favs()
        pass

    def get_favs(self):
        if len(self._favs) == 0:
            self._load_favs()
            pass

        result = []

        for fav_id in self._favs:
            fav_data = self._favs.get(fav_id, None)

            item = DirectoryItem(name=fav_data.get('name', ''),
                                 path=fav_data.get('path', None),
                                 params=fav_data.get('params', {}))
            item.set_fanart(fav_data.get('fanart', u''))
            item.set_image_url(fav_data.get('thumb', u''))
            result.append(item)
            pass

        return result

    def remove_fav(self, base_item):
        self._load_favs()
        fav_id = self._create_id_from_item(base_item)
        if fav_id in self._favs:
            del self._favs[fav_id]
            self._store_favs()
            pass
        pass

    @staticmethod
    def create_directory_item_from_params(params):
        new_item = DirectoryItem(name='dummy', path='dummy')

        new_item._path = params.get('path', None)
        new_item._name = params.get('name', '').decode('utf-8')
        new_item._image_url = params.get('thumb', u'')
        new_item._fanart = params.get('fanart', None)
        new_item._params = json.loads(params.get('params', '').replace("'", "\""))

        return new_item
    pass