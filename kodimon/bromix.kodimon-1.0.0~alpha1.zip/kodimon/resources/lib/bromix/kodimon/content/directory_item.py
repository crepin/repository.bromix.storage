from base_item import BaseItem


class DirectoryItem(BaseItem):
    def __init__(self, name, path, params={}, image_url=u''):
        BaseItem.__init__(self, name, path, params, image_url)
        pass
    pass