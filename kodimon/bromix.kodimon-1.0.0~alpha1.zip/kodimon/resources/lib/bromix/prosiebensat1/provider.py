import re

from client import Client

from resources.lib.bromix import kodimon
from resources.lib.bromix.kodimon import constants
from resources.lib.bromix.kodimon.helper import contextmenu, FavsManager
from resources.lib.bromix.kodimon.content import RegisterPath, AbstractProvider, DirectoryItem, VideoItem


class Provider(AbstractProvider):
    __CHANNEL_ID_STRING__ = 'pro7|sat1|kabel1|sixx|sat1gold|prosiebenmaxx'

    def __init__(self, plugin):
        AbstractProvider.__init__(self, plugin)

        self._client = Client()

        self._channel_id_list = ['pro7', 'sat1', 'kabel1', 'sixx', 'sat1gold', 'prosiebenmaxx']
        self._channel_data = {'pro7': {'name': u'ProSieben'},
                              'sat1': {'name': u'SAT.1'},
                              'kabel1': {'name': u'kabel eins'},
                              'sixx': {'name': u'sixx'},
                              'sat1gold': {'name': u'SAT.1 Gold'},
                              'prosiebenmaxx': {'name': u'ProSieben MAXX'}
        }

        self.register_default_search({'search.new': 30008,
                                      'search.new.title': 30000,
                                      'search.context.remove': 30009
        }
        )

        self.register_default_favs_support({'favs.remove': 30013})
        pass

    def on_search(self, search_text, path, params, re_match):
        result = []
        json_data = self._client.search(search_text)
        screen = json_data.get('screen', {})
        screen_objects = screen.get('screen_objects', [])
        for screen_object in screen_objects:
            sub_screen_objects = screen_object.get('screen_objects', [])
            for sub_screen_object in sub_screen_objects:
                title = screen_object.get('title', '')
                if title == 'Sendungen':
                    channel_reference = sub_screen_object.get('channel_reference', [])
                    channel_id = channel_reference[0]
                    format_path = "/%s/library/" % (channel_id)
                    result.append(self._screen_object_to_item(format_path, sub_screen_object))
                    pass
                elif title == 'Ganze Folgen':
                    channel_reference = sub_screen_object.get('channel_reference', [])
                    channel_id = channel_reference[0]
                    result.append(self._screen_object_to_item('/play/', sub_screen_object))
                    pass
                elif title == 'Highlights':
                    channel_reference = sub_screen_object.get('channel_reference', [])
                    channel_id = channel_reference[0]
                    result.append(self._screen_object_to_item('/play/', sub_screen_object))
                    pass
                pass
            pass

        return result

    @RegisterPath('^/(' + __CHANNEL_ID_STRING__ + ')/highlights/?$')
    def _get_channel_highlights(self, path, params, re_match):
        channel_id = re_match.group(1)

        result = []

        channel_image = "media/channels/%s.png" % channel_id
        channel_image = self.get_plugin().create_resource_path(channel_image)

        category = params.get('category', None)
        if category == None:
            """
            Popular Shows
            """
            item = DirectoryItem(name=self.localize(30005, u'Popular Shows'),
                                 path=kodimon.create_content_path([channel_id, 'highlights']),
                                 params={'category': 'Beliebte Sendungen'},
                                 image_url=channel_image
            )
            item.set_fanart(self.get_plugin().get_fanart())
            result.append(item)

            """
            Current Entire Episodes
            """
            item = DirectoryItem(name=self.localize(30006, u'Current Entire Episodes'),
                                 path=kodimon.create_content_path([channel_id, 'highlights']),
                                 params={'category': 'Aktuelle ganze Folgen'},
                                 image_url=channel_image
            )
            item.set_fanart(self.get_plugin().get_fanart())
            result.append(item)

            """
            Newest Clips
            """
            item = DirectoryItem(name=self.localize(30007, u'Newest Clips'),
                                 path=kodimon.create_content_path([channel_id, 'highlights']),
                                 params={'category': 'Neueste Clips'},
                                 image_url=channel_image
            )
            item.set_fanart(self.get_plugin().get_fanart())
            result.append(item)
        else:
            json_data = self._client.get_homepage(channel_id)
            screen = json_data.get('screen', {})
            screen_objects = screen.get('screen_objects', [])
            for screen_object in screen_objects:
                if screen_object.get('type', '') == 'sushi_bar':
                    if screen_object.get('title', '') == category:
                        sub_screen_objects = screen_object.get('screen_objects', [])
                        for sub_screen_object in sub_screen_objects:
                            format_path = kodimon.create_content_path([channel_id, 'library'])
                            result.append(self._screen_object_to_item(format_path, sub_screen_object))
                            pass
                        break
                    pass
                pass

            if category == 'Beliebte Sendungen':
                result = self.sort_items_by_name(result)
                pass
            pass

        return result

    @RegisterPath('^/play/$')
    def _play(self, path, params, re_match):
        video_id = params.get('id', '')
        if video_id == '':
            raise kodimon.KodimonException("Missing parameter 'id' to play video")

        json_data = self._client.get_video_url(video_id)
        video_url = json_data.get('VideoURL', '')
        if video_url == '':
            raise kodimon.KodimonException("Could not resolve url for video '%s'" % (video_id))

        item = VideoItem(name=video_id,
                         path='/')
        item.set_url(video_url)

        return item

    @RegisterPath('^/(' + __CHANNEL_ID_STRING__ + ')/library/(\d+)/$')
    def _get_format_content(self, path, params, re_match):
        channel_id = re_match.group(1)
        clip_type = params.get('clip_type', 'full')
        page = int(params.get('page', '1'))

        self.get_plugin().set_content_type(constants.CONTENT_TYPE_EPISODES)

        result = []

        channel_image = "media/channels/%s.png" % channel_id
        channel_image = self.get_plugin().create_resource_path(channel_image)

        if page == 1 and clip_type == 'full':
            clipsItem = DirectoryItem(name=self.localize(30004, u'Clips'),
                                      path=kodimon.create_content_path(path),
                                      params={'clip_type': 'short'},
                                      image_url=channel_image
            )
            result.append(clipsItem)
            pass

        format_id = re_match.group(2)

        json_data = self._client.get_format_videos(channel_id, format_id, clip_type=clip_type, page=page)
        videos = json_data.get('objects', [])
        videoList = []
        for video in videos:
            videoList.append(self._screen_object_to_item(path, video))
            pass

        self.sort_video_items_by_info_label(videoList)
        result.extend(videoList)

        if (self._client.has_more_videos(channel_id, format_id, clip_type=clip_type, current_page=page)):
            new_params = {}
            new_params.update(params)
            new_params['page'] = str(page + 1)
            name = self.localize(30010, 'Next Page')
            if (name.find('%d') != -1):
                name = name % (page + 1)
                pass
            nextPageItem = DirectoryItem(name=name,
                                         path=path,
                                         params=new_params
            )
            result.append(nextPageItem)
            pass

        return result

    """
    Content of one category of one channel
    
    <Channel> = pro7|sat1|...
    <Category> = highlights|library|archive
    
    <Channel>/<Category>/*
    """

    @RegisterPath('^/(' + __CHANNEL_ID_STRING__ + ')/library/$')
    def _get_channel_content_by_category(self, path, params, re_match):
        self.get_plugin().set_content_type(constants.CONTENT_TYPE_TVSHOWS)
        self.get_plugin().add_sort_method(constants.SORT_METHOD_LABEL_IGNORE_THE)

        channel_id = re_match.group(1)
        category = params.get('category', 'Aktuell')

        result = []

        json_data = self._client.get_format(channel_id)
        screen = json_data.get('screen', {})
        screen_objects = screen.get('screen_objects', {})

        if len(screen_objects) > 0:
            screen_objects = screen_objects[0]
            screen_objects = screen_objects.get('screen_objects', {})

            for screen_object in screen_objects:
                if screen_object.get('type', '') == 'grid_page' and screen_object.get('title', '') == category:

                    sub_screen_objects = screen_object.get('screen_objects', [])
                    for sub_screen_object in sub_screen_objects:
                        result.append(self._screen_object_to_item(path, sub_screen_object))
                        pass
                    pass
                pass
            pass

        result = self.sort_items_by_name(result)

        return result

    """
    Content of one channel
    
    <Channel> = pro7|sat1|...
    
    <Channel>/Highlights
    <Channel>/Library
    <Channel>/Archive
    """

    @RegisterPath('^/(' + __CHANNEL_ID_STRING__ + ')/$')
    def _get_channel_content(self, path, params, re_match):
        channel_id = re_match.group(1)

        result = []

        channel_image = "media/channels/%s.png" % channel_id
        channel_image = self.get_plugin().create_resource_path(channel_image)

        """
        highlights
        """
        item = DirectoryItem(name=self.localize(30001, u'Highlights'),
                             path=kodimon.create_content_path([channel_id, 'highlights']),
                             image_url=channel_image
        )
        item.set_fanart(self.get_plugin().get_fanart())
        result.append(item)

        """
        Library
        """
        item = DirectoryItem(name=self.localize(30002, u'Library'),
                             path=kodimon.create_content_path([channel_id, 'library']),
                             params={'category': 'Aktuell'},
                             image_url=channel_image
        )
        item.set_fanart(self.get_plugin().get_fanart())
        result.append(item)

        """
        Archive
        """
        item = DirectoryItem(name=self.localize(30003, u'Archive'),
                             path=kodimon.create_content_path([channel_id, 'library']),
                             params={'category': 'Archiv'},
                             image_url=channel_image
        )
        item.set_fanart(self.get_plugin().get_fanart())
        result.append(item)

        return result

    @RegisterPath('^/favs/latest/$')
    def _latest_video(self, path, params, re_match):
        result = []

        fav_manager = FavsManager(self._plugin)
        directory_items = fav_manager.get_favs()

        format_ids = []
        for directory_item in directory_items:
            path = directory_item.get_path();
            re_match = re.match('/('+self.__CHANNEL_ID_STRING__+')/(library)/(\d+)/', path)
            if re_match is not None:
                channel_id = re_match.group(1)
                format_id = re_match.group(3)
                format_ids.append("%s:%s" % (channel_id, format_id))
                pass
            pass

        json_data = self._client.get_new_videos(format_ids)
        screen_objects = json_data.get('screen_objects', [])
        for screen_object in screen_objects:
            result.append(self._screen_object_to_item(path, screen_object))
            pass

        return result

    @RegisterPath('^/$')
    def _get_root_items(self, path, params, re_match):
        result = []

        """
        Favs
        """
        fav_mananer = FavsManager(self._plugin)
        if len(fav_mananer.get_favs()) > 0:
            fav_item = DirectoryItem(name='[B]' + self.localize(30012, u'Favorites') + '[/B]',
                                     path=kodimon.create_content_path([self.INTERNAL_FAVS_PATH, 'list']),
                                     image_url=self.get_plugin().create_resource_path('media/highlight.png'))
            fav_item.set_fanart(self.get_plugin().get_fanart())
            result.append(fav_item)

            latest_item = DirectoryItem(name='[B]' + self.localize(30014, u'Latest Videos') + '[/B]',
                                        path=kodimon.create_content_path(['favs', 'latest']),
                                        image_url=self.get_plugin().create_resource_path('media/highlight.png'))
            latest_item.set_fanart(self.get_plugin().get_fanart())
            result.append(latest_item)
            pass

        """
        Search
        """
        search_item = DirectoryItem(name='[B]' + self.localize(30000, u'Search...') + '[/B]',
                                    path=kodimon.create_content_path(self.INTERNAL_SEARCH_PATH),
                                    image_url=self.get_plugin().create_resource_path('media/search.png'))
        search_item.set_fanart(self.get_plugin().get_fanart())
        result.append(search_item)

        """
        Channels
        """
        for channel in self._channel_id_list:
            channel_data = self._channel_data.get(channel, {})
            channel_image = "media/channels/%s.png" % channel
            channel_image = self.get_plugin().create_resource_path(channel_image)
            channel_item = DirectoryItem(name=channel_data.get('name', channel),
                                         path=kodimon.create_content_path(channel),
                                         image_url=channel_image)
            channel_item.set_fanart(self.get_plugin().get_fanart())
            result.append(channel_item)
            pass

        return result

    def _screen_object_to_item(self, path, screen_object):
        screen_object_type = screen_object.get('type', '')
        if screen_object_type == '':
            raise kodimon.KodimonException('Missing type for screenObject')

        if screen_object_type == 'format_item' or screen_object_type == 'format_item_home':
            format_id = screen_object['id']
            format_id = format_id.split(':')
            format_id = format_id[1]

            format_item = DirectoryItem(name=screen_object['title'],
                                        path=kodimon.create_content_path([path, format_id]),
                                        image_url=screen_object.get('image_url', u''))
            format_item.set_fanart(self.get_plugin().get_fanart())
            try:
                context_menu = [contextmenu.create_default_add_to_favs(self._plugin,
                                                                       self.localize(30011, 'Add to addon favs'),
                                                                       format_item)]

                format_item.set_context_menu(context_menu)
            except UnicodeEncodeError, ex:
                kodimon.log(format_item.get_name())
                pass
            return format_item
        elif screen_object_type == 'video_item_date' or screen_object_type == 'video_item_format_no_label' or screen_object_type == 'video_item_format':
            name = screen_object.get('title', None)
            if name is None:
                name = screen_object.get('video_title', '')
                pass

            """
            prepend the format name to the episode
            """
            if screen_object_type == 'video_item_format_no_label' or screen_object_type == 'video_item_format' or screen_object.get('video_item_type', None) == None:
                format_name = screen_object.get('format_title', None)
                if format_name is not None:
                    name = format_name + ' - ' + name
                    pass
                pass

            video_item = VideoItem(name=name,
                                   path=kodimon.create_content_path('play'),
                                   params={'id': screen_object['id']},
                                   image_url=screen_object.get('image_url', u'')
            )
            video_item.set_duration_in_seconds(int(screen_object.get('duration', '60')))
            video_item.set_aired_as_string(self._convert_to_aired(screen_object.get('start', '0000-00-00T0')))
            video_item.set_fanart(self.get_plugin().get_fanart())

            self._try_set_season_and_episode(video_item)
            return video_item

        raise kodimon.KodimonException("Unknown type '%s' for screen_object" % screen_object_type)

    def _try_set_season_and_episode(self, video_item):
        """
        First try to get an episode and after that the season
        """
        re_match = re.search("Staffel (\d+)", video_item.get_name())
        if re_match is not None:
            video_item.set_season(re_match.group(1))
            pass
        re_match = re.search("(Episode|Folge) (\d+)", video_item.get_name())
        if re_match is not None:
            video_item.set_episode(re_match.group(2))
            pass
        pass

    def _convert_to_aired(self, date_string):
        _data = date_string.split('T')
        return _data[0]