import unittest

from resources.lib.bromix import kodimon


class TestVideoItem(unittest.TestCase):
    def setUp(self):
        pass

    def test_set_duration_in_minutes(self):
        item = kodimon.VideoItem(name="Some good movie",
                                 path="/play/")
        item.set_duration_in_minutes(120)

        info_label = item.create_info_label()
        self.assertEqual('120', info_label.get('duration', ''))
        pass

    def test_set_duration_in_seconds(self):
        item = kodimon.VideoItem(name="Some good movie",
                                 path="/play/")
        item.set_duration_in_seconds(120)
        info_label = item.create_info_label()
        self.assertEqual('2', info_label.get('duration', ''))
        pass

    def test_set_aired(self):
        item = kodimon.VideoItem(name="Some good movie",
                                 path="/play/")

        """
        We provide mixed int and string types to test if the method convert every value correct. 
        """
        item.set_aired(2014, '2', 4)
        info_label = item.create_info_label()
        self.assertEqual('2014-02-04', info_label.get('aired', ''))
        pass


if __name__ == "__main__":
    unittest.main()
    pass