import unittest

from resources.lib.bromix import kodimon


class TestPluginSettings(unittest.TestCase):
    def setUp(self):
        plugin = kodimon.Plugin()
        self._settings = plugin.get_settings()
        pass
    
    def test_set_string(self):
        self._settings.set_string('name', 'value')
        self.assertEqual('value', self._settings.get_string('name'))
        pass
    
    def test_get_string(self):
        self.assertEqual(None, self._settings.get_string('name'))
        self.assertEqual('default', self._settings.get_string('name', 'default'))
        pass
    
    def test_set_int(self):
        self._settings.set_int('int_value', 10)
        self.assertEqual(10, self._settings.get_int('int_value', 20))
        pass
    
    def test_set_bool(self):
        self._settings.set_bool('bool_value', False)
        self.assertEqual(False, self._settings.get_bool('bool_value', True))
        
        self._settings.set_bool('bool_value', True)
        self.assertEqual(True, self._settings.get_bool('bool_value', False))
        pass

if __name__ == "__main__":
    unittest.main()
    pass