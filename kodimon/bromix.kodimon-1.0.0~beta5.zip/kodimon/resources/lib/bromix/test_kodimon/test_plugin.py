import unittest
import tempfile

from resources.lib.bromix import kodimon


class TestPlugin(unittest.TestCase):
    def setUp(self):
        self._plugin = kodimon.Plugin('PluginName', 'PluginId')
        pass

    def test_get_data_path(self):
        temp_path = tempfile.gettempdir()

        self.assertEqual(temp_path, self._plugin.get_data_path())
        pass

    def test_get_name(self):
        self.assertEqual('PluginName', self._plugin.get_name())
        pass

    def test_get_id(self):
        self.assertEqual('PluginId', self._plugin.get_id())
        pass

    def test_get_native_path(self):
        path = self._plugin.get_native_path()
        self.assertEqual('addon', path)
        pass

    def test_get_fanart(self):
        path = self._plugin.get_fanart()
        self.assertEqual('addon\\fanart.jpg', path)
        pass

    def test_create_resource_path(self):
        path = self._plugin.create_resource_path('/media/channels/pro7')

        self.assertEqual('addon\\resources\\media\\channels\\pro7', path)
        pass

    def test_create_url(self):
        url = self._plugin.create_url(path='search', params={'q': 'Galileo'})
        self.assertEqual(url, 'plugin://PluginId/search/?q=Galileo')
        pass

    def test_create_url_from_item(self):
        item = kodimon.DirectoryItem(name='Playlists',
                                     path='/playlists/')
        url = self._plugin.create_url_from_item(item)
        self.assertEqual(url, 'plugin://PluginId/playlists/')

        item = kodimon.VideoItem(name='Some good movie',
                                 path='/play/',
                                 params={'id': '123456'})
        url = self._plugin.create_url_from_item(item)
        self.assertEqual(url, 'plugin://PluginId/play/?id=123456')
        pass

    def test_localize_by_mapping(self):
        mapping = {'search.new': 30000}
        text = self._plugin.localize_by_mapping('search.new', mapping, 'OK')
        self.assertEqual('OK', text)

        text = self._plugin.localize_by_mapping('search.new', mapping)
        self.assertEqual('search.new', text)
        pass


if __name__ == "__main__":
    unittest.main()
    pass