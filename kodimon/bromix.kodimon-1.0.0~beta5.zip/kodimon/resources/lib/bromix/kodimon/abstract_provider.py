import re
import os
import urllib


class AbstractProvider(object):
    INTERNAL_SEARCH_PATH = 'bromix.kodimon.search'
    INTERNAL_FAVS_PATH = 'bromix.kodimon.favs'
    INTERNAL_WATCH_LATER_PATH = 'bromix.kodimon.watch_later'

    def __init__(self, plugin=None):
        """
        Default constructor for a new content provider.
        You can provide an alternative implementation of a plugin. If the given
        plugin is None we try to get a implementation the good way :)

        :param plugin:
        :return:
        """
        self._plugin = None
        if plugin is None:
            from . import Plugin

            self._plugin = Plugin()
        else:
            self._plugin = plugin
            pass

        cache_path = os.path.join(self._plugin.get_data_path(), '.cache')
        if not os.path.exists(cache_path):
            os.makedirs(cache_path)
            pass
        cache_filename = os.path.join(cache_path, 'cache.db')
        from .helper import FunctionCache

        self._function_cache = FunctionCache(filename=cache_filename)
        self._refresh_container_on_search = False
        self._path_mapping = {}
        self._localization_mapping = {}

        """
        We provide some basic (internal) pathes so we don't need to develope all over again and again and again...
        """
        self.register_path('^/$', '_internal_root')
        self.register_path('^/' + self.INTERNAL_WATCH_LATER_PATH + '/(add|remove|list)/?$', '_internal_watch_later')
        self.register_path('^/' + self.INTERNAL_FAVS_PATH + '/(add|remove|list)/?$', '_internal_favs')
        self.register_path('^/' + self.INTERNAL_SEARCH_PATH + '/((.*)/)?$', '_internal_search')

        """
        Test each method of this class for the appended attribute '_re_match' by the
        decorator (RegisterPath).
        The '_re_match' attributes describes the path which must match for the decorated method.
        """

        for method_name in dir(self):
            method = getattr(self, method_name)
            if hasattr(method, '_re_path'):
                self.register_path(method._re_path, method_name)
                pass
            pass
        pass

    def update_localization_map(self, localization_map):
        self._localization_mapping.update(localization_map)

    def get_plugin(self):
        return self._plugin

    def localize(self, text_id, default_text=None):
        return self._plugin.localize_by_mapping(text_id, self._localization_mapping)

    def register_path(self, re_path, method_name):
        self._path_mapping[re_path] = method_name

    def navigate(self, path, params=None):
        if not params:
            params = {}
            pass

        for key in self._path_mapping:
            re_match = re.search(key, path)
            if re_match is not None:
                method_name = self._path_mapping.get(key, '')
                method = getattr(self, method_name)
                if method is not None:
                    return method(path, params, re_match)
                pass
            pass

        from . import KodimonException

        raise KodimonException("Mapping for path '%s' not found" % path)

    def on_search(self, search_text, path, params, re_match):
        raise NotImplementedError()

    def on_root(self, path, params, re_match):
        raise NotImplementedError()

    def _internal_root(self, path, params, re_match):
        return self.on_root(path, params, re_match)

    def _internal_favs(self, path, params, re_match):
        from .helper import FavsList

        favs_list = FavsList(self._plugin)

        command = re_match.group(1)
        if command == 'add':
            from . import json_to_item

            fav_item = json_to_item(params['item'])
            favs_list.add(fav_item)
            pass
        elif command == 'remove':
            from . import json_to_item

            fav_item = json_to_item(params['item'])
            favs_list.remove(fav_item)
            from . import refresh_container

            refresh_container()
            pass
        elif command == 'list':
            from . import sort_items_by_name

            directory_items = sort_items_by_name(favs_list.list())

            """
            We override the context menu so the user can remove a fav from the list.
            """
            from . import contextmenu

            for directory_item in directory_items:
                context_menu = []
                remove_item = contextmenu.create_default_remove_from_favs(self._plugin,
                                                                          self.localize('kodimon.favs.remove'),
                                                                          directory_item)
                context_menu.append(remove_item)
                directory_item.set_context_menu(context_menu)
                pass

            return directory_items
        else:
            pass
        pass

    def _internal_watch_later(self, path, params, re_match):
        from . import constants

        self._plugin.set_content_type(constants.CONTENT_TYPE_EPISODES)

        from .helper import WatchLaterList

        watch_later_list = WatchLaterList(self._plugin)

        command = re_match.group(1)
        if command == 'add':
            from . import json_to_item
            from . import VideoItem

            item = json_to_item(params['item'])
            if isinstance(item, VideoItem):
                """
                We set a 'dateadded' info label, so we can sort the list based on that.
                """
                import datetime

                now = datetime.datetime.now()
                item.set_date_added_string(now.strftime('%Y-%m-%d %H:%M:%S'))
                pass
            watch_later_list.add(item)
            pass
        elif command == 'remove':
            from . import json_to_item

            item = json_to_item(params['item'])
            watch_later_list.remove(item)
            from . import refresh_container

            refresh_container()
            pass
        elif command == 'list':
            from . import contextmenu
            from . import sort_items_by_info_label

            video_items = sort_items_by_info_label(watch_later_list.list(), info_label='dateadded')

            """
            We override the context menu so the user can remove a video from the list.
            """
            for video_item in video_items:
                context_menu = []
                remove_item = contextmenu.create_default_remove_from_watch_later(self._plugin,
                                                                                 self.localize('kodimon.favs.remove'),
                                                                                 video_item)
                context_menu.append(remove_item)
                video_item.set_context_menu(context_menu)
                pass

            return video_items
        else:
            # do something
            pass
        pass

    def _internal_search(self, path, params, re_match):
        from .abstract_api import debug_here
        #debug_here()
        from . import refresh_container, create_content_path
        from .helper import SearchHistory

        search_history = SearchHistory(self.get_plugin())
        search_text = re_match.group(2)
        if search_text is not None and search_text != '':
            search_text = urllib.unquote(search_text)
            search_history.update(search_text)
            if self._refresh_container_on_search:
                refresh_container()
                pass
            return self.on_search(search_text, path, params, re_match)

        if search_history.is_empty() or params.get('command', '') == 'new':
            from . import input

            result, text = input.on_keyboard_input(self.localize('kodimon.search.title'))
            if result:
                search_history.update(text)
                if self._refresh_container_on_search:
                    refresh_container()
                    pass
                return self.on_search(text, path, params, re_match)
            pass
        elif params.get('command', '') == 'remove':
            search_history.remove(params.get('name', ''))
            refresh_container()
            pass
        else:
            result = []

            from . import DirectoryItem

            """
            Provide a "New Search..." command.
            """
            directory_item = DirectoryItem(name='[B]' + self.localize('kodimon.search.new') + '[/B]',
                                           path=create_content_path(self.INTERNAL_SEARCH_PATH),
                                           params={'command': 'new'},
                                           image=self.get_plugin().create_resource_path('media/search.png'))

            directory_item.set_fanart(self.get_plugin().get_fanart())
            result.append(directory_item)

            """
            Add each item from the search history. 
            """
            from . import contextmenu
            for item in search_history.get_items():
                directory_item = DirectoryItem(name=item,
                                               path=create_content_path([self.INTERNAL_SEARCH_PATH, item]),
                                               params={'page': 1},
                                               image=self.get_plugin().create_resource_path('media/search.png'))
                directory_item.set_fanart(self.get_plugin().get_fanart())

                context_menu = [contextmenu.create_run_plugin(self._plugin,
                                                              self.localize('kodimon.search.remove'),
                                                              path=self.INTERNAL_SEARCH_PATH,
                                                              params={'command': 'remove',
                                                                      'name': item})]
                directory_item.set_context_menu(context_menu)
                result.append(directory_item)
                pass

            return result

        return False

    def call_function_cached(self, partial_func, seconds, return_cached_only=False):
        return self._function_cache.get(partial_func=partial_func, seconds=seconds,
                                        return_cached_only=return_cached_only)

    pass