import hashlib


class BaseItem(object):
    def __init__(self, name, path, params=None, image=u''):
        if not params:
            params = {}
            pass

        self._name = unicode(name)
        self._path = unicode(path)
        self._image = ""
        self._url = ""
        self._params = params
        self._fanart = ""
        self._context_menu = None

        self.set_image(image)

    def get_id(self):
        """
        Returns a unique id of the item.
        :return: unique id of the item.
        """
        m = hashlib.md5()
        m.update(self._name.encode('utf-8'))
        m.update(self._path.encode('utf-8'))
        for key in self._params:
            m.update(key.encode('utf-8'))
            m.update(self._params.get(key, '').encode('utf-8'))
            pass
        return m.hexdigest()

    def get_name(self):
        """
        Returns the name of the item.
        :return: name of the item.
        """
        return self._name

    def get_path(self):
        """
        Returns the path of the item.
        :return: path of the item.
        """
        return self._path

    def set_url(self, url):
        """
        Sets the url of the item
        :param url:
        :return:
        """
        if url:
            self._url = unicode(url)
        else:
            self._url = ""
        pass

    def get_url(self):
        return self._url

    def get_params(self):
        return self._params

    def set_image(self, image):
        if image:
            self._image = unicode(image)
        else:
            self._image = u''
        pass

    def get_image(self):
        return self._image

    def set_fanart(self, fanart):
        if fanart:
            self._fanart = fanart
        pass

    def get_fanart(self):
        return self._fanart

    def set_context_menu(self, context_menu):
        if len(context_menu) == 0:
            self._context_menu = None
        else:
            self._context_menu = context_menu
        pass

    def get_context_menu(self):
        return self._context_menu

    pass