def on_keyboard_input(title, default='', hidden=False):
    print '[' + title + ']'
    var = raw_input("Please enter something: ")
    if var is not None and var != '':
        return True, var

    return False, ''