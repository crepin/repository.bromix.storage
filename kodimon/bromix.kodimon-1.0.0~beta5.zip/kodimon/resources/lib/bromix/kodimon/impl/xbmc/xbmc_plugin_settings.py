from ....kodimon.abstract_settings import AbstractSettings


class XbmcPluginSettings(AbstractSettings):
    def __init__(self, plugin):
        AbstractSettings.__init__(self)
        
        self._plugin = plugin
        pass
        
    def get_string(self, setting_id, default_value=None):
        return self._plugin._addon.getSetting(setting_id)
    
    def set_string(self, setting_id, value):
        self._plugin._addon.setSetting(setting_id, value)
        pass
    
    pass