import json


def create_run_plugin(plugin, label, path='', params=None):
    if not params:
        params = {}
        pass

    return (label, 'RunPlugin('+plugin.create_url(path, params)+')')


def create_default_add_to_favs(plugin, label, base_item):
    import abstract_api as kodimon
    params = {'item': json.dumps(kodimon.item_to_json(base_item))}
    return create_run_plugin(plugin, label, path='/bromix.kodimon.favs/add/', params=params)


def create_default_remove_from_favs(plugin, label, base_item):
    import abstract_api as kodimon
    params = {'item': json.dumps(kodimon.item_to_json(base_item))}
    return create_run_plugin(plugin, label, path='/bromix.kodimon.favs/remove/', params=params)


def create_default_add_to_watch_later(plugin, label, base_item):
    import abstract_api as kodimon
    params = {'item': json.dumps(kodimon.item_to_json(base_item))}
    return create_run_plugin(plugin, label, path='/bromix.kodimon.watch_later/add/', params=params)


def create_default_remove_from_watch_later(plugin, label, base_item):
    import abstract_api as kodimon
    params = {'item': json.dumps(kodimon.item_to_json(base_item))}
    return create_run_plugin(plugin, label, path='/bromix.kodimon.watch_later/remove/', params=params)