import json
import os

__author__ = 'bromix'


class ItemStorage(object):
    def __init__(self, filename):
        self._filename = filename

        self._opened = False
        self._data = {}

    pass

    def _load(self):
        if not self._opened:
            path = os.path.dirname(self._filename)
            if not os.path.exists(path):
                os.makedirs(path)
                pass

            if os.path.exists(self._filename):
                try:
                    self._data = json.loads(open(self._filename).read(), encoding='utf-8')
                    self._opened = True
                except:
                    self._data = {}
            pass

    def _store(self):
        with open(self._filename, "w") as outfile:
            json.dump(self._data, outfile, indent=4, encoding='utf-8')
        pass

    def add(self, base_item):
        self._load()

        item_id = base_item.get_id()
        from ...kodimon import item_to_json

        self._data[item_id] = item_to_json(base_item)

        self._store()
        pass

    def clear(self):
        self._data = {}
        self._store()
        pass

    def list(self):
        self._load()

        result = []
        from ...kodimon import json_to_item

        for key in self._data:
            result.append(json_to_item(self._data[key]))
            pass

        return result

    def remove(self, base_item):
        self._load()

        item_id = base_item.get_id()
        if item_id in self._data:
            del self._data[item_id]
            self._store()
            pass
        pass

    pass