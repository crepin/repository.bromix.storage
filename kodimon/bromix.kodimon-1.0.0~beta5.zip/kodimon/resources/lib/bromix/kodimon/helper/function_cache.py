import os

try:
    from cPickle import UnpicklingError
except ImportError:
    from pickle import UnpicklingError
    pass
import shelve
import time

__author__ = 'bromix'

import hashlib


class FunctionCache(object):
    ONE_MINUTE = 60
    ONE_HOUR = 60*ONE_MINUTE
    ONE_DAY = 24*ONE_HOUR
    ONE_WEAK = 7*ONE_DAY
    ONE_MONTH = 4*ONE_WEAK

    def __init__(self, filename):
        self._filename = filename
        self._cache_file = None
        pass

    def __del__(self):
        if self._cache_file is not None:
            self._cache_file.close()
            pass
        pass

    def _create_id_from_func(self, partial_func):
        """
        Creats an id from the given function
        :param partial_func:
        :return: id for the given function
        """
        m = hashlib.md5()
        m.update(partial_func.func.__module__)
        m.update(partial_func.func.__name__)
        m.update(str(partial_func.args))
        m.update(str(partial_func.keywords))
        return m.hexdigest()

    def _get_cached_data(self, cache_id, tries_left=2):
        if tries_left==0:
            raise Exception("Something went really wrong here!")

        """
        Internal helper method to read the cached data.
        :param cache_id:
        :return: cached_time and cached_data
        """
        cached_time = -1
        cached_data = None

        data = None
        try:
            if self._cache_file is None:
                self._cache_file = shelve.open(self._filename, writeback=True)
                pass


            if cache_id in self._cache_file:
                data = self._cache_file[cache_id]
                pass
        except Exception, ex:
            from ... import kodimon
            from ...kodimon import constants
            kodimon.log("Failed to 'unpickle' object '%s'" % ex.__str__(), log_level=constants.LOG_ERROR)
            kodimon.log("Resetting function cache...", log_level=constants.LOG_INFO)
            if self._cache_file is not None:
                self._cache_file.close()
                self._cache_file = None
                pass
            os.remove(self._filename)
            kodimon.log("Resetting function cache...Done", log_level=constants.LOG_INFO)
            return self._get_cached_data(cache_id=cache_id, tries_left=tries_left-1)

        if data is not None:
            cached_time = data[0]
            cached_data = data[1]
            pass

        return cached_time, cached_data

    def get(self, partial_func, seconds, return_cached_only=False):
        """
        Returns the cached data of the given function.
        :param partial_func: function to cache
        :param seconds: time to live in seconds
        :param return_cached_only: return only cached data and don't call the function
        :return:
        """
        cache_id = self._create_id_from_func(partial_func)

        cached_time, cached_data = self._get_cached_data(cache_id)

        if return_cached_only:
            return cached_data

        now = time.time()
        if cached_data is None or now-cached_time > seconds:
            cached_data = partial_func()
            self._cache_file[cache_id] = (now, cached_data)
            self._cache_file.sync()
            pass

        return cached_data
    pass
