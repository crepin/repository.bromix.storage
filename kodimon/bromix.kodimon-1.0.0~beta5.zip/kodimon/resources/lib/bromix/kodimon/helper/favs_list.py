__author__ = 'bromix'

import os

from item_storage import ItemStorage


class FavsList(ItemStorage):
    def __init__(self, plugin):
        ItemStorage.__init__(self, os.path.join(plugin.get_data_path(), u'bromix', u'kodimon', 'favs.json'))
        self._plugin = plugin
        pass