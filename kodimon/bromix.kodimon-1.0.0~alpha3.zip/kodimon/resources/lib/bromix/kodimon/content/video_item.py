from base_item import BaseItem


class VideoItem(BaseItem):
    def __init__(self, name, path, params={}, image_url=u''):
        BaseItem.__init__(self, name, path, params, image_url)
        self._duration = '1'
        
        self._aired = None
        self._season = None
        self._episode = None
        pass
    
    def set_season(self, season):
        self._season = season
        pass
    
    def set_episode(self, episode):
        self._episode = episode
        pass
    
    def create_info_label(self):
        _info_label = {'title': self.get_name(),
                       'duration': self._duration
                       }
        
        if self._aired is not None:
            _info_label['aired']=self._aired
        if self._season is not None:
            _info_label['season']=self._season
        if self._episode is not None:
            _info_label['episode']=self._episode
        
        return _info_label
    
    def set_aired_as_string(self, year_month_day):
        self._aired = year_month_day
        pass
    
    def set_aired(self, year, month, day):
        _data = [year, month, day]
        for i in range(len(_data)):
            _val = _data[i]
            if isinstance(_val, int):
                _val = str(_val)
                pass
            
            if len(_val)==1:
                _val='0'+_val
                pass
            
            _data[i]=_val
            pass
            
        self._aired = '%s-%s-%s' % (_data[0], _data[1], _data[2])
        pass
    
    def set_duration_in_minutes(self, int_minutes):
        self.set_duration_in_seconds(int_minutes*60)
        pass
    
    def set_duration_in_seconds(self, int_seconds):
        minutes_str = 1
        
        minutes = int_seconds/60
        if minutes==0:
            minutes_str = 1
        else:
            minutes_str = str(minutes)
        
        self._duration = minutes_str
        pass

    pass