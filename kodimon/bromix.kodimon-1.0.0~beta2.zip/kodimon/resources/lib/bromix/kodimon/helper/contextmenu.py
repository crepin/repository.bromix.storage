def create_run_plugin(plugin, label, path='', params={}):
    return (label, 'RunPlugin('+plugin.create_url(path, params)+')')

def create_default_add_to_favs(plugin, label, base_item):
    params = {'name': base_item.get_name().encode('utf-8'),
              'path': base_item.get_path(),
              'params': base_item.get_params(),
              'thumb': base_item.get_image_url()}

    if base_item.get_fanart() is not None:
        params['fanart'] = base_item.get_fanart()
    
    return create_run_plugin(plugin, label, path='/bromix.kodimon.favs/add/', params=params)

def create_default_remove_from_favs(plugin, label, base_item):
    params = {'name': base_item.get_name().encode('utf-8'),
              'path': base_item.get_path(),
              'params': base_item.get_params(),
              'thumb': base_item.get_image_url()}

    if base_item.get_fanart() is not None:
        params['fanart'] = base_item.get_fanart()

    return create_run_plugin(plugin, label, path='/bromix.kodimon.favs/remove/', params=params)