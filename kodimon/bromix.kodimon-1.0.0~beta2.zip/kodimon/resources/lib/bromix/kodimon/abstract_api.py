import urllib

"""
Abstract declaration of global methods. The methods must be implemented and will
be overridden by the import of the implementation.

This prevents us from forgetting to write methods in the implementation.
"""


def run(content_provider):
    raise NotImplementedError()


def log(text, log_level=2):
    raise NotImplementedError()


def refresh_container():
    raise NotImplementedError()


def create_content_path(path_list):
    def _string_to_list(path):
        return path.split('/')
        pass

    quoted_list = []
    if isinstance(path_list, basestring):
        path_list = _string_to_list(path_list)
        pass

    if isinstance(path_list, list):
        for item in path_list:
            if item is not None and item != '':
                sub_items = _string_to_list(item)
                for sub_item in sub_items:
                    if sub_item is not None and sub_item != '':
                        quoted_list.append(urllib.quote(sub_item.strip('/')))
                        pass
                    pass
                pass
            pass
        pass

    result = "/".join(quoted_list)
    result = "/" + result + "/"
    return result