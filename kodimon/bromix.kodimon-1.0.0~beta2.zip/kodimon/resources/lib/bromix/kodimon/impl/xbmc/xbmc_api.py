import xbmc
import xbmcgui
import xbmcplugin

def run(content_provider):
    from ....kodimon import KodimonException
    from ....kodimon.content import VideoItem, DirectoryItem
    from ....kodimon import constants
    
    plugin = content_provider.get_plugin()
    path = plugin.get_path()
    params = plugin.get_params()
    
    result = None
    try:
        result = content_provider.navigate(path, params)
    except KodimonException, ex:
        log(ex[0], constants.LOG_ERROR)
        xbmcgui.Dialog().ok("Exception in ContentProvider", ex.args[0])
        pass
    
    if isinstance(result, bool) and result==False:
        xbmcplugin.endOfDirectory(plugin.get_handle(), succeeded=False)
    elif isinstance(result, VideoItem):
        _set_resolved_url(plugin, result)
    elif isinstance(result, list):
        item_count = len(result)
        for content_item in result:
            if isinstance(content_item, DirectoryItem):
                _add_directory(plugin, content_item, item_count)
            elif isinstance(content_item, VideoItem):
                _add_video(plugin, content_item, item_count)
            pass
        
        xbmcplugin.endOfDirectory(plugin.get_handle(), succeeded=True)
        pass
    else:
        # handle exception
        pass
    pass

def log(text, log_level=2):
    xbmc.log(msg=text, level=log_level)
    pass

def refresh_container():
    xbmc.executebuiltin("Container.Refresh")
    pass

def _set_resolved_url(plugin, base_item, succeeded=True):
    listitem = xbmcgui.ListItem(path=base_item.get_url())
    xbmcplugin.setResolvedUrl(plugin.get_handle(), True, listitem)
    
    """
    # just to be sure :)
    if not isLiveStream:
        tries = 100
        while tries>0:
            xbmc.sleep(50)
            if xbmc.Player().isPlaying() and xbmc.getCondVisibility("Player.Paused"):
                xbmc.Player().pause()
                break
            tries-=1
    """

def _add_directory(plugin, directoryItem, itemCount=0):
    url = plugin.create_url_from_item(directoryItem)
    
    item = xbmcgui.ListItem(label=directoryItem.get_name(),
                            iconImage=u'DefaultFolder.png',
                            thumbnailImage=directoryItem.get_image_url()
                            )
    
    if directoryItem.get_fanart() is not None:
        item.setProperty("fanart_image", directoryItem.get_fanart())
        pass
    if directoryItem.get_context_menu() is not None:
        item.addContextMenuItems(directoryItem.get_context_menu());
        pass
        
    xbmcplugin.addDirectoryItem(handle=plugin.get_handle(),
                                url=url,
                                listitem=item,
                                isFolder=True,
                                totalItems=itemCount
                                )
    
def _add_video(plugin, videoItem, itemCount=0):
    url = plugin.create_url_from_item(videoItem)
    
    item = xbmcgui.ListItem(label=videoItem.get_name(),
                            iconImage=u'DefaultVideo.png',
                            thumbnailImage=videoItem.get_image_url()
                            )
    
    if videoItem.get_fanart() is not None:
        item.setProperty("fanart_image", videoItem.get_fanart())
        pass
    if videoItem.get_context_menu() is not None:
        item.addContextMenuItems(videoItem.get_context_menu());
        pass
    
    item.setProperty('IsPlayable', 'true')
    
    item.setInfo(type="video",
                 infoLabels=videoItem.create_info_label()
                 )
        
    xbmcplugin.addDirectoryItem(handle=plugin.get_handle(),
                                url=url,
                                listitem=item,
                                totalItems=itemCount
                                )