import unittest
import re

from resources.lib.bromix import kodimon
from resources.lib.bromix import prosiebensat1


class TestProvider(unittest.TestCase):
    def setUp(self):
        unittest.TestCase.setUp(self)
        
        self._plugin = kodimon.Plugin()
        self._provider = prosiebensat1.Provider(self._plugin)
        pass

    def test_format_next_page(self):
        self._plugin.set_path('/pro7/library/505/')
        kodimon.run(self._provider)
        pass
    
    def test_root(self):
        rootItems = self._provider.navigate('/')
        self.assertEqual(len(rootItems), 7)
        pass
    
    def test_channel_content(self):
        channelItems = self._provider.navigate('/pro7/')
        self.assertEqual(len(channelItems), 3)
        pass
    
    def test_search_with_history(self):
        self._plugin.get_settings().set_string('bromix.kodimon.search.history', 'tree|batman|some%20stuff|last%20entry')
        result = self._provider.navigate(kodimon.create_content_path(self._provider.INTERNAL_SEARCH_PATH))
        self.assertEqual(5, len(result))
        pass

    """
    def test_search_without_history(self):
        self._plugin.get_settings().set_string('bromix.kodimon.search.history', '')
        self._plugin.set_path(kodimon.create_content_path(self._provider.INTERNAL_SEARCH_PATH))
        kodimon.run(self._provider)
        pass
    """
    
    def test_channel_content_by_category(self):
        self._plugin.set_path('/pro7/library/')
        kodimon.run(self._provider)
        pass
    
    def test_format_content(self):
        self._plugin.set_path('/pro7/library/277/')
        kodimon.run(self._provider)
        pass
    
    def test_publishing_date(self):
        aired = self._provider._convert_to_aired('2014-09-02T14:45:00+02:00')
        self.assertEqual(aired, '2014-09-02')
        pass

if __name__ == "__main__":
    unittest.main()
    pass