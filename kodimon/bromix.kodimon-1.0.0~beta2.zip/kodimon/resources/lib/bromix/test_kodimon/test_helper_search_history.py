import unittest

from resources.lib.bromix import kodimon
from resources.lib.bromix.kodimon.helper import SearchHistory

def create_history(plugin, initial_string, size=10):
    settings = plugin.get_settings()
    settings.set_string('bromix.kodimon.search.history', initial_string)
    settings.set_int('bromix.kodimon.search.history.size', size)
    history = SearchHistory(plugin)
    return history

class TestSearchHistory(unittest.TestCase):
    def setUp(self):
        self._plugin = kodimon.Plugin()
        pass
    
    def test_get_items(self):
        history = create_history(self._plugin, 'tree|batman|some%20stuff|last%20entry')
        items = history.get_items()
        self.assertEqual(4, len(items))
        self.assertEqual('tree|batman|some%20stuff|last%20entry', history._create_string())
        pass
    
    def test_clear(self):
        history = create_history(self._plugin, 'tree|batman|some%20stuff|last%20entry')
        history.clear()
        items = history.get_items()
        self.assertEqual(0, len(items))
        self.assertEqual('', history._create_string())
        pass
    
    def test_is_empty(self):
        history = create_history(self._plugin, 'tree|batman|some%20stuff|last%20entry')
        history.clear()
        self.assertEqual(True, history.is_empty())
        pass
    
    def test_remove(self):
        history = create_history(self._plugin, 'tree|batman|some%20stuff|last%20entry')
        history.remove('batman')
        items = history.get_items()
        self.assertEqual(3, len(items))
        self.assertEqual('tree|some%20stuff|last%20entry', history._create_string())
        pass
    
    def test_update_append(self):
        history = create_history(self._plugin, 'tree|batman|some%20stuff|last%20entry')
        history.update('batman')
        items = history.get_items()
        self.assertEqual(4, len(items))
        self.assertEqual('batman', items[0])
        self.assertEqual('batman|tree|some%20stuff|last%20entry', history._create_string())
        pass
    
    def test_update_size(self):
        history = create_history(self._plugin, 'tree|batman|some%20stuff|last%20entry', size=4)
        history.update('new entry')
        items = history.get_items()
        self.assertEqual(4, len(items))
        self.assertEqual('new entry', items[0])
        self.assertEqual('some stuff', items[3])
        self.assertEqual('new%20entry|tree|batman|some%20stuff', history._create_string())
        pass

if __name__ == "__main__":
    unittest.main()
    pass