from resources.lib import kodimon
from resources.lib import netzkino

__provider__ = netzkino.Provider()
kodimon.run(__provider__)