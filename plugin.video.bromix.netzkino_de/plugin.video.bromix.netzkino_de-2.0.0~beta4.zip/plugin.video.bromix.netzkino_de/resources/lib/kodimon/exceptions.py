__author__ = 'bromix'


class KodimonException(Exception):
    pass
