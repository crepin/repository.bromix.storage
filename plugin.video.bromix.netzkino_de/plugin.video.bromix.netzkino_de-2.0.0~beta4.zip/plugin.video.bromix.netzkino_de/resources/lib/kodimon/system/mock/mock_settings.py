from ..abstract_settings import AbstractSettings
from ...log import *


class MockSettings(AbstractSettings):
    def __init__(self):
        AbstractSettings.__init__(self)

        self._settings = {}
        pass

    def get_string(self, settings_id, default_value=None):
        return self._settings.get(settings_id, default_value)

    def set_string(self, settings_id, value):
        self._settings[settings_id] = value
        pass

    def open_settings(self):
        log("called 'open_settings'")
        pass

    pass