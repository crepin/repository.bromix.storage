import xbmc
import xbmcgui
import xbmcplugin


def run(content_provider):
    from ....kodimon import KodimonException, VideoItem, DirectoryItem

    plugin = content_provider.get_plugin()
    path = plugin.get_path()
    params = plugin.get_params()

    result = None
    try:
        result = content_provider.navigate(path, params)
    except KodimonException, ex:
        from ... import constants
        log(ex[0], constants.LOG_ERROR)
        xbmcgui.Dialog().ok("Exception in ContentProvider", ex.args[0])
        pass

    if isinstance(result, bool) and not result:
        xbmcplugin.endOfDirectory(plugin.get_handle(), succeeded=False)
    elif isinstance(result, VideoItem):
        _set_resolved_url(plugin, result)
    elif isinstance(result, list):
        item_count = len(result)
        for content_item in result:
            if isinstance(content_item, DirectoryItem):
                _add_directory(plugin, content_item, item_count)
            elif isinstance(content_item, VideoItem):
                _add_video(plugin, content_item, item_count)
            pass

        xbmcplugin.endOfDirectory(plugin.get_handle(), succeeded=True)
        pass
    else:
        # handle exception
        pass
    pass


def log(text, log_level=2):
    xbmc.log(msg=text, level=log_level)
    pass


def refresh_container():
    xbmc.executebuiltin("Container.Refresh")
    pass


def _set_resolved_url(plugin, base_item, succeeded=True):
    listitem = xbmcgui.ListItem(path=base_item.get_url())
    xbmcplugin.setResolvedUrl(plugin.get_handle(), True, listitem)

    """
    # just to be sure :)
    if not isLiveStream:
        tries = 100
        while tries>0:
            xbmc.sleep(50)
            if xbmc.Player().isPlaying() and xbmc.getCondVisibility("Player.Paused"):
                xbmc.Player().pause()
                break
            tries-=1
    """


def _add_directory(plugin, directory_item, item_count=0):
    url = plugin.create_url_from_item(directory_item)

    item = xbmcgui.ListItem(label=directory_item.get_name(),
                            iconImage=u'DefaultFolder.png',
                            thumbnailImage=directory_item.get_image())

    if directory_item.get_fanart() is not None:
        item.setProperty("fanart_image", directory_item.get_fanart())
        pass
    if directory_item.get_context_menu() is not None:
        item.addContextMenuItems(directory_item.get_context_menu())
        pass

    xbmcplugin.addDirectoryItem(handle=plugin.get_handle(),
                                url=url,
                                listitem=item,
                                isFolder=True,
                                totalItems=item_count)


def _add_video(plugin, video_item, item_count=0):
    url = plugin.create_url_from_item(video_item)

    item = xbmcgui.ListItem(label=video_item.get_name(),
                            iconImage=u'DefaultVideo.png',
                            thumbnailImage=video_item.get_image())

    if video_item.get_fanart() is not None:
        item.setProperty("fanart_image", video_item.get_fanart())
        pass
    if video_item.get_context_menu() is not None:
        item.addContextMenuItems(video_item.get_context_menu())
        pass

    item.setProperty('IsPlayable', 'true')

    item.setInfo(type="video",
                 infoLabels=video_item.create_info_label())

    xbmcplugin.addDirectoryItem(handle=plugin.get_handle(),
                                url=url,
                                listitem=item,
                                totalItems=item_count
    )