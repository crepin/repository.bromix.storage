import json
import urllib

"""
Abstract declaration of global methods. The methods must be implemented and will
be overridden by the import of the implementation.

This prevents us from forgetting to write methods in the implementation.
"""


def debug_here():
    """
    For debugging at a particular position in your plugin call this method.
    :return:
    """
    import pydevd
    pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    pass


def run(content_provider):
    """
    Needs to be implemented by a mock for testing or the real deal.
    This will execute the provider and pipe the content to kodi.
    :param content_provider:
    :return:
    """
    raise NotImplementedError()


def log(text, log_level=2):
    """
    Needs to be implemented by a mock for testing or the real deal.
    Logging.
    :param text:
    :param log_level:
    :return:
    """
    raise NotImplementedError()


def refresh_container():
    """
    Needs to be implemented by a mock for testing or the real deal.
    This will refresh the current container or list.
    :return:
    """
    raise NotImplementedError()


def create_content_path(path_list):
    """
    This will return a clean path by the given string or list of strings ['path1', 'path2']
    :param path_list:
    :return:
    """

    def _string_to_list(path):
        return path.split('/')
        pass

    quoted_list = []
    if isinstance(path_list, basestring):
        path_list = _string_to_list(path_list)
        pass

    if isinstance(path_list, list):
        for item in path_list:
            if item is not None and item != '':
                sub_items = _string_to_list(item)
                for sub_item in sub_items:
                    if sub_item is not None and sub_item != '':
                        quoted_list.append(urllib.quote(sub_item.strip('/')))
                        pass
                    pass
                pass
            pass
        pass

    result = "/".join(quoted_list)
    result = "/" + result + "/"
    return result


def json_to_item(json_data):
    """
    Creates a instance of the given json dump or dict.
    :param json_data:
    :return:
    """

    def _from_json(_json_data):
        from .video_item import VideoItem
        from .directory_item import DirectoryItem

        mapping = {'VideoItem': VideoItem,
                   'DirectoryItem': DirectoryItem}

        item = None
        item_type = _json_data.get('type', None)
        for key in mapping:
            if item_type == key:
                item = mapping[key]('dummy', 'dummy')
                break
            pass

        if item is None:
            return _json_data

        data = _json_data.get('data', {})
        for key in data:
            if hasattr(item, key):
                setattr(item, key, data[key])
                pass
            pass

        return item

    if isinstance(json_data, basestring):
        json_data = json.loads(json_data)
    return _from_json(json_data)


def item_to_json(base_item):
    """
    Convert the given @base_item to json
    :param base_item:
    :return: json string
    """

    def _to_json(obj):
        from .video_item import VideoItem
        from .directory_item import DirectoryItem

        if isinstance(obj, dict):
            return obj.__dict__

        mapping = {VideoItem: 'VideoItem',
                   DirectoryItem: 'DirectoryItem'}

        for key in mapping:
            if isinstance(obj, key):
                return {'type': mapping[key], 'data': obj.__dict__}
            pass

        return obj.__dict__

    return _to_json(base_item)


def sort_items_by_name(content_items=None, reverse=False):
    """
    Sort the list of items based on their name.
    :param content_items:
    :param reverse:
    :return:
    """
    if not content_items:
        content_items = []

    def _sort(item):
        return item.get_name().upper()

    return sorted(content_items, key=_sort, reverse=reverse)


def sort_items_by_info_label(content_items=None, info_label='aired', reverse=False):
    """
    Sort the list of item based on the given info label.
    :param content_items:
    :param info_label:
    :param reverse:
    :return:
    """
    if not content_items:
        content_items = []
        pass

    def _sort(item):
        _info_labels = item.create_info_label()
        return _info_labels.get(info_label, '')

    sorted_list = sorted(content_items, key=_sort, reverse=reverse)
    return sorted_list