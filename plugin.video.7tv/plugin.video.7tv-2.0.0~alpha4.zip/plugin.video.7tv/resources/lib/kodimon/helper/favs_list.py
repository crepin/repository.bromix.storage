__author__ = 'bromix'

import os

from item_storage import ItemStorage


class FavsList(ItemStorage):
    def __init__(self, plugin):
        ItemStorage.__init__(self, os.path.join(plugin.get_data_path(), u'kodimon', u'favs.db'))
        self._plugin = plugin
        pass

    def clear(self):
        self._clear()
        pass

    def list(self):
        result = []

        for key in self._get_ids():
            item = self._get(key)
            if item is not None:
                result.append(self._get(key))
            pass

        from .. import sort_items_by_name
        return sort_items_by_name(result)

    def add(self, base_item):
        self._add(base_item.get_id(), base_item)
        pass

    def remove(self, base_item):
        self._remove(base_item.get_id())
        pass