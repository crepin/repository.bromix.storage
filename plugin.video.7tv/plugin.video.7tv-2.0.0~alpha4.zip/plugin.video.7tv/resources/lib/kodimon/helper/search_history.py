import hashlib
import os
import datetime
from item_storage import ItemStorage


class SearchHistory(ItemStorage):
    def __init__(self, plugin, size=10):
        ItemStorage.__init__(self, os.path.join(plugin.get_data_path(), u'kodimon', u'search.db'))
        self._plugin = plugin
        self._size = size
        pass

    def is_empty(self):
        return self._is_empty()

    def list(self):
        result = []

        for key in self._get_ids():
            result.append(self._get(key))
            pass

        result = sorted(result, key=self._sort, reverse=True)
        return result

    def clear(self):
        self._clear()

    def remove(self, search_text):
        self._remove(self._make_id(search_text))
        pass

    def _make_id(self, search_text):
        m = hashlib.md5()
        m.update(search_text.encode('utf-8'))
        return m.hexdigest()

    def _sort(self, x):
        return x[1]

    def update(self, search_text):
        search_id = self._make_id(search_text)
        self._add(search_id, (search_text, unicode(datetime.datetime.now())))

        items = self.list()
        if len(items) > self._size:
            cut_off = len(items) - self._size
            items = sorted(items, key=self._sort, reverse=False)
            for i in range(cut_off):
                item = items[i]
                item_id = self._make_id(item[0])
                self._remove(item_id)
                pass
            pass
        pass

    pass