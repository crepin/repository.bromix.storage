import os
import shelve

__author__ = 'bromix'


class ItemStorage(object):
    def __init__(self, filename):
        self._filename = filename

        self._file = None

    pass

    def __del__(self):
        if self._file is not None:
            self._file.sync()
            self._file.close()
            self._file = None
            pass
        pass

    def _open(self):
        if self._file is None:
            path = os.path.dirname(self._filename)
            if not os.path.exists(path):
                os.makedirs(path)
                pass

            self._file = shelve.open(self._filename, writeback=True)
        pass

    def sync(self):
        self._open()
        if self._file is not None:
            self._file.sync()
            pass
        pass

    def _add(self, item_id, item):
        self._open()
        self._file[item_id] = item
        pass

    def _clear(self):
        self._open()
        self._file.clear()
        pass

    def _is_empty(self):
        self._open()
        return len(self._file) == 0

    def _get_ids(self):
        self._open()
        return self._file.keys()

    def _get(self, item_id):
        self._open()
        try:
            return self._file.get(item_id, None)
        except ImportError, ex:
            from ... import kodimon

            kodimon.log("Failed to load item with id '%s' (%s)" % (item_id, ex.__str__()), kodimon.constants.LOG_ERROR)
            kodimon.log("Resetting database...", kodimon.constants.LOG_INFO)
            self._clear()
            self.sync()
            kodimon.log("Resetting database...Done", kodimon.constants.LOG_INFO)
            pass
        pass

    def _remove(self, item_id):
        self._open()
        if item_id in self._file:
            del self._file[item_id]
            pass
        pass

    pass