from resources.lib.bromix import prosiebensat1
__provider__ = prosiebensat1.Provider()

from resources.lib.bromix import kodimon
kodimon.run(__provider__)