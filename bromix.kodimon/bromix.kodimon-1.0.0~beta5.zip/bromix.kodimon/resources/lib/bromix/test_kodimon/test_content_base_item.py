import unittest

from resources.lib.bromix import kodimon


class TestBaseItem(unittest.TestCase):
    def setUp(self):
        pass

    def test_get_name(self):
        item = kodimon.BaseItem(name="Playlists",
                                path="/playlists/")

        self.assertEqual("Playlists", item.get_name())
        pass

    def test_get_path(self):
        item = kodimon.BaseItem(name="Playlists",
                                path="/playlists/")

        self.assertEqual("/playlists/", item.get_path())
        pass

    def test_get_params(self):
        item = kodimon.BaseItem(name="Playlists",
                                path="/playlists/",
                                params={'id': '123456', 'id2': 'abcdef'})

        self.assertEqual(item.get_params().get('id', ''), '123456')
        self.assertEqual(item.get_params().get('id2', ''), 'abcdef')
        pass

    def test_set_image(self):
        item = kodimon.BaseItem(name="Playlists",
                                path="/playlists/",
                                params={'id': '123456', 'id2': 'abcdef'},
                                image=None)

        self.assertEqual(item.get_image(), u'')

        item.set_image('stuff')
        self.assertEqual(item.get_image(), 'stuff')

        item.set_image(None)
        self.assertEqual(item.get_image(), '')
        pass

    def test_get_image(self):
        item = kodimon.BaseItem(name="Playlists",
                                path="/playlists/",
                                params={'id': '123456', 'id2': 'abcdef'},
                                image='some_url')

        self.assertEqual(item.get_image(), 'some_url')
        pass

    def test_get_fanart(self):
        item = kodimon.BaseItem(name="Playlists",
                                path="/playlists/")
        item.set_fanart('some_fanart')

        self.assertEqual(item.get_fanart(), 'some_fanart')
        pass


if __name__ == "__main__":
    unittest.main()
    pass