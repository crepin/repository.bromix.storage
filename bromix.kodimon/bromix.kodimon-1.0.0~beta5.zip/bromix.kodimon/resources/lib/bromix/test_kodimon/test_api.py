import unittest

from resources.lib.bromix import kodimon


class TestApi(unittest.TestCase):
    def setUp(self):
        pass
    
    def test_log(self):
        kodimon.log("Hello")
        pass
    
    def test_create_content_path(self):
        path = kodimon.create_content_path(['search/', '/new', 'entry'])
        self.assertEqual('/search/new/entry/', path)
        
        path = kodimon.create_content_path(['search/ups', '/new', 'entry'])
        self.assertEqual('/search/ups/new/entry/', path)
        
        path = kodimon.create_content_path('search//new/entry////')
        self.assertEqual('/search/new/entry/', path)
        pass

    def test_item_to_json(self):
        item_in = kodimon.DirectoryItem(name='adada',
                                        path='/pro7/library/277/',
                                        params={'param1': 'value1',
                                                'param2': 'value2'},
                                        image='/path/to/image.jpg')
        item_in.set_fanart('/path/to/fanart.jpg')
        item_in.set_url(1)

        json = kodimon.item_to_json(item_in)

        data = json['data']
        self.assertEqual('adada', data['_name'])
        self.assertEqual('/pro7/library/277/', data['_path'])
        self.assertEqual('/path/to/image.jpg', data['_image'])
        self.assertEqual('/path/to/fanart.jpg', data['_fanart'])
        pass

    def test_json_to_item(self):
        item_in = kodimon.DirectoryItem(name='adada',
                                        path='/pro7/library/277/',
                                        params={'param1': 'value1',
                                                'param2': 'value2'},
                                        image='/path/to/image.jpg')
        item_in.set_fanart('/path/to/fanart.jpg')
        item_in.set_url(1)

        json = kodimon.item_to_json(item_in)

        item_out = kodimon.json_to_item(json)
        self.assertEqual('adada', item_out.get_name())
        self.assertEqual('/pro7/library/277/', item_out.get_path())
        self.assertEqual('/path/to/image.jpg', item_out.get_image())
        self.assertEqual('/path/to/fanart.jpg', item_out.get_fanart())
        pass

if __name__ == "__main__":
    unittest.main()
    pass