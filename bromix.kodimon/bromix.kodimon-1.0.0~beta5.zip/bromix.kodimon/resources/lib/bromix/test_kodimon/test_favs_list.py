# -*- coding: utf-8 -*-
from resources.lib.bromix.kodimon import contextmenu

__author__ = 'bromix'

import unittest
import urlparse
import re

from resources.lib.bromix import kodimon
from resources.lib.bromix.kodimon.helper import FavsList


class TestFavsList(unittest.TestCase):
    def setUp(self):
        self._plugin = kodimon.Plugin()
        pass

    def test_fav_item(self):
        item = kodimon.DirectoryItem(name=u'Crash Games - Jeder Sturz zählt',
                                     path='/pro7/library/277/',
                                     params={'param1': 'value1',
                                             'param2': 'value2'},
                                     image='/path/to/image.jpg')
        item.set_fanart('/path/to/fanart.jpg')

        context_item = contextmenu.create_default_add_to_favs(self._plugin,
                                                              'Add me to favs',
                                                              item)
        params = {}
        re_match = re.match("RunPlugin\((.*)\)", context_item[1])
        if re_match is not None:
            url_components = urlparse.urlparse(re_match.group(1))
            path = url_components[2]
            query = url_components[4]
            params = dict(urlparse.parse_qsl(query))
            pass

        fav_item = kodimon.json_to_item(params['item'])

        self.assertEqual(fav_item.get_name(), u'Crash Games - Jeder Sturz zählt')
        self.assertEqual(fav_item.get_path(), '/pro7/library/277/')
        self.assertEqual(fav_item.get_image(), '/path/to/image.jpg')
        self.assertEqual(fav_item.get_fanart(), '/path/to/fanart.jpg')
        self.assertEqual(fav_item.get_params().get('param1', None), 'value1')
        self.assertEqual(fav_item.get_params().get('param2', None), 'value2')
        pass

    def test_add_fav(self):
        item = kodimon.DirectoryItem(name=u'Crash Games - Jeder Sturz zählt',
                                     path='/pro7/library/277/',
                                     params={'param1': 'value1',
                                             'param2': 'value2'},
                                     image='image url')
        item.set_fanart('fanart url')

        favs_manager = FavsList(self._plugin)

        # remove any existing favs
        favs_manager.clear()
        favs = favs_manager.list()
        self.assertEqual(0, len(favs))

        # add one fav
        favs_manager.add(item)
        favs = favs_manager.list()
        self.assertEqual(1, len(favs))

        # add the same fav again
        favs_manager.add(item)
        favs = favs_manager.list()
        self.assertEqual(1, len(favs))
        pass

    def test_remove_fav(self):
        item = kodimon.DirectoryItem(name=u'Crash Games - Jeder Sturz zählt',
                                     path='/pro7/library/277/',
                                     params={'param1': 'value1',
                                             'param2': 'value2'},
                                     image='image url')
        item.set_fanart('fanart url')

        favs_manager = FavsList(self._plugin)

        # remove any existing favs
        favs_manager.clear()
        favs = favs_manager.list()
        self.assertEqual(0, len(favs))

        # add one fav
        favs_manager.add(item)
        favs = favs_manager.list()
        self.assertEqual(1, len(favs))

        # remove the fav from before
        favs_manager.remove(item)
        favs = favs_manager.list()
        self.assertEqual(0, len(favs))
        pass

    def test_sort(self):
        item = kodimon.DirectoryItem(name=u'Crash Games - Jeder Sturz zählt',
                                     path='/pro7/library/277/',
                                     params={'param1': 'value1',
                                             'param2': 'value2'},
                                     image='image url')
        item.set_fanart('fanart url')

        item2 = kodimon.DirectoryItem(name=u'Ärash Games - Jeder Sturz zählt',
                                      path='/pro7/library/277/',
                                      params={'param1': 'value1',
                                              'param2': 'value2'},
                                      image='image url')
        item2.set_fanart('fanart url')

        favs_manager = FavsList(self._plugin)

        # remove any existing favs
        favs_manager.clear()
        favs = favs_manager.list()
        self.assertEqual(0, len(favs))

        # add one fav
        favs_manager.add(item)
        favs_manager.add(item2)
        favs = favs_manager.list()
        self.assertEqual(2, len(favs))

        # remove the fav from before
        favs_manager.remove(item)
        favs = favs_manager.list()
        self.assertEqual(1, len(favs))
        pass

    pass