import os
from functools import partial

__author__ = 'bromix'

import unittest
from resources.lib.bromix import kodimon
from resources.lib.bromix.kodimon.helper import FunctionCache


class TestFunctionCache(unittest.TestCase):
    def setUp(self):
        self._plugin = kodimon.Plugin()

        cache_path = os.path.join(self._plugin.get_data_path(), '.cache')
        if not os.path.exists(cache_path):
            os.makedirs(cache_path)
            pass
        cache_filename = os.path.join(cache_path, 'cache.db')

        self._function_cache = FunctionCache(filename=cache_filename)
        pass

    def test_call_function(self):
        def _add(x, y):
            return x + y

        result = self._function_cache.get(partial(_add, 5, 6), seconds=60)
        result = self._function_cache.get(partial(_add, 5, 6), seconds=60)
        pass

    pass
