import unittest

from resources.lib.bromix import kodimon
from resources.lib.bromix import prosiebensat1


class TestProvider(unittest.TestCase):
    def setUp(self):
        unittest.TestCase.setUp(self)

        self._provider = prosiebensat1.Provider()
        self._plugin = self._provider.get_plugin()
        pass

    def test_format_next_page(self):
        self._plugin.set_path('/pro7/library/505/')
        kodimon.run(self._provider)
        pass
    
    def test_root(self):
        root_items = self._provider.navigate('/')
        self.assertEqual(len(root_items), 9)
        pass
    
    def test_channel_content(self):
        channel_items = self._provider.navigate('/pro7/')
        self.assertEqual(len(channel_items), 3)
        pass

    def test_channel_content(self):
        channel_items = self._provider.navigate('/pro7/')
        self.assertEqual(len(channel_items), 3)
        pass
    
    def test_search_with_history(self):
        self._plugin.get_settings().set_string('kodimon.search.history', 'tree|batman|some%20stuff|last%20entry')
        result = self._provider.navigate(kodimon.create_content_path(self._provider.INTERNAL_SEARCH_PATH))
        self.assertEqual(5, len(result))
        pass

    """
    def test_search_without_history(self):
        self._plugin.get_settings().set_string('kodimon.search.history', '')
        self._plugin.set_path(kodimon.create_content_path(self._provider.INTERNAL_SEARCH_PATH))
        kodimon.run(self._provider)
        pass
    """
    
    def test_channel_content_by_category(self):
        self._plugin.set_path('/pro7/library/')
        kodimon.run(self._provider)
        pass
    
    def test_format_content(self):
        self._plugin.set_path('/pro7/library/277/')
        kodimon.run(self._provider)
        pass
    
    def test_publishing_date(self):
        aired = prosiebensat1.convert_to_aired('2014-09-02T14:45:00+02:00')
        self.assertEqual(aired, '2014-09-02')
        pass

if __name__ == "__main__":
    unittest.main()
    pass